import time
file = open("controller.txt","r")
strt = file.readline()
file.close()
if strt == "0":
    per = []
    pername = []




    print("\n")
    print("--------------------------------------------------")
    print("PySh - PyShort lang compiler")
    print("for learn PySh - write imp help")
    print("v0.2.4; enter command")
    print("--------------------------------------------------")
    print(">>>")
    def command(command):
        if command.rsplit("{")[0] == "prt":
            try:
                com1 = command.rsplit("{")
                index = com1[1]
                if "'" in index:
                    b = index.rsplit("'")
                elif '"' in index:
                    b = index.rsplit('"')
                else:
                    cnt = 0
                    if com1[1] in pername:
                        for line in pername:
                            if line == com1[1]:
                                break
                            else:
                                cnt += 1
                        return per[cnt]
                    else:
                        return f"Error 003: name {index} does not exist in current context"
                return b[1]
            except IndexError:
                return "Error 002: command have not enough arguments"

        elif command.rsplit("{")[0] == "pass":
            return ""
        elif command.split()[0] == "imp":
            try:
                if command.split()[1] == "help":
                    return"Help and learn PyShort you can on http://bit.do/fSgVG"
                elif (command.split()[1] == "dev") or (command.split()[1] == "log"):
                    return "Lang - PyShort (PySh) \nThe Language created for fast learn Python \n Can compile .pysh files \n The creator is: \n Discord AxeliXDEV#3154 \n Telegram @axelixdev \n last build in 19.10.2021"
                else:
                    return "Error 005: Can not import this lib"
            except IndexError:
                return "Error 004: nothing to import"
        elif command.split()[0] == "per":
            try:
                if command.split()[1] in pername:
                    cnt = 0
                    com1 = command.split()
                    for line in pername:
                        if line == com1[1]:
                            break
                        else:
                            cnt += 1
                    per.remove(per[cnt])
                    pername.remove(command.split()[1])
                try:
                    com1 = command.split()
                    pername.append(com1[1])
                    try:
                        per.append(int(com1[3]))
                    except ValueError:
                        per.append(com1[3])
                    return ""
                except IndexError:
                    return "Error 002: command have not enough arguments"
            except IndexError:
                return "Error 002: command have not enough arguments"
        elif command.split()[0] == "cf":
            try:
                file = open(f"{command.split[1]}","r")
                file.close()
                return "this function on working"
            except FileNotFoundError:
                return "Error 006: Can not open the file"
            #return "compiled"
        else:
            return f"Error 001: command {command} does not exist"
    try:
        while True:
            com = input()
            print(command(com))
    except KeyboardInterrupt:
        print("--------------------------------------------------")
        print("You stopped the compiler")
        print("--------------------------------------------------")
        exit()
else:
    print("Error 007: missing required files")
    time.sleep(3)
    exit()